import React from "react";
import "./App.css";
import edu from "./images/educ.png";
// Add imports at the top of your App.js
import { FaLinkedin, FaInstagram, FaGithub } from "react-icons/fa";
import { SiGmail } from "react-icons/si";
import { Fade } from "react-awesome-reveal";
import FlipCard from "./components/FlipCard";
import deansList from "./images/deansList.jpg";
import {
  VerticalTimeline,
  VerticalTimelineElement,
} from "react-vertical-timeline-component";
import "react-vertical-timeline-component/style.min.css";
import iiithLogo from "./images/iiith.jpeg";
import taLogo from "./images/TA.png";
import walmartLogo from "./images/walmart_logo.jpeg";
import CircularGallery from "./components/CircularGallery";

function App() {
  return (
    <div className="app-container">
      {/* Home Section */}
      <section className="hero">
        <nav>
          <ul>
            <li>
              <a href="/">Home</a>
            </li>
            <li>
              <a href="#education">Education</a>
            </li>
            <li>
              <a href="#experience">Experience</a>
            </li>
            <li>
              <a href="#projects">Projects</a>
            </li>
            <li>
              <a href="#contact">Contact</a>
            </li>
          </ul>
          <a href="/" className="btn">
            Resume
          </a>
        </nav>

        <div className="content">
          <span className="title">Web Developer</span>
          <h1>
            Hello, I'm <span>Geethika</span>
          </h1>
          <p style={{ fontSize: "18px" }}>
            I'm a B.Tech graduate with a passion for technology and
            problem-solving. As a web developer, I craft responsive and
            user-friendly websites. I enjoy turning ideas into digital experiences
            using clean, efficient code. Eager to grow, I'm always learning new
            tools and frameworks.
          </p>

          <div
            style={{
              marginTop: "30px",
              display: "flex",
              alignItems: "left",
              gap: "15px",
            }}
          >
            <a
              href="https://www.linkedin.com/in/thota-geethika/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaLinkedin size={30} color="#0077b5" />
            </a>
            <a
              href="mailto:thotageethika12@gmail.com"
              target="_blank"
              rel="noopener noreferrer"
            >
              <SiGmail size={30} color="#D44638" />
            </a>
            <a
              href="https://www.instagram.com/geethu_613/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaInstagram size={30} color="#E4405F" />
            </a>
            <a
              href="https://github.com/iamgeethika"
              target="_blank"
              rel="noopener noreferrer"
            >
              <FaGithub size={30} color="#000000" />
            </a>
          </div>
        </div>
      </section>

      {/* Education Section - Now a separate section, not absolutely positioned */}
      <section id="education" className="education-section" style={{
        minHeight: "100vh",
        width: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        padding: "50px 0" // Add padding instead of absolute positioning
      }}>
        {/* Education Heading */}
        <Fade direction="down">
          <span style={{
            fontSize: "2.5em",
            margin: "0 0 40px 0",
            textAlign: "center",
            color: "#DC143C",
            // fontFamily: "birthstone",
            background: "radial-gradient( rgba(255,105,180,0.4) 0%, rgba(255,20,147,0.1) 60%, rgba(0,0,0,0) 90%)",
          }}>
            Education
          </span>
        </Fade>

        {/* Container for the side-by-side layout */}
        <div
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "row",
            flexWrap: "wrap",
          }}
        >
          {/* Left side with image */}
          <div
            style={{
              flex: "1 1 50%",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Fade
              direction="left"
              style={{
                width: "100%",
                display: "flex",
                justifyContent: "center",
              }}
            >
              <img
                src={edu}
                alt="Education Icon"
                style={{
                  width: "500px",
                  maxWidth: "100%",
                }}
              />
            </Fade>
          </div>

          {/* Right side with education details */}
          <div
            style={{
              flex: "1 1 50%",
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              padding: "10px",
              paddingLeft: "5px",
              gap: "20px",
            }}
          >
            <Fade
              direction="right"
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
            >
              {/* FlipCard Component for Education */}
              <FlipCard
                backImage={deansList}
                backImageAlt="My Deans List Image"
                frontContent={
                  <>
                    <h2>International Institute of Information Technology, Hyderabad</h2>
                    <p>Bachelor of Technology in Computer Science</p>
                    <p>2021 - 2025</p>
                    <p className="highlight">GPA: 8.44</p>
                  </>
                }
              />
              <div>
                <li>
                  <p style={{ marginTop: "10px" }}>
                    My academic background encompasses foundational computer science disciplines, including data systems, algorithms, software design and analysis, distributed systems, and operating systems. I have also pursued specialized studies in statistical methods for artificial intelligence.
                  </p>
                </li>
                <li>
                  <p style={{ textAlign: "left" }}>
                    I was honoured with <b>Deans List 1</b> in Monsoon 2023 for Academic Excellence.
                  </p>
                </li>
                <li>
                  <p style={{ textAlign: "left" }}>
                    I also worked as a <b>Teaching Assistant</b> for Linear Algebra and Algorithm Analysis and Design courses.
                  </p>
                </li>
              </div>
            </Fade>
          </div>
        </div>
      </section>

      <center id="experience">
        <Fade direction="down">
          <span style={{
            fontSize: "2.5em",
            margin: "0 0 40px 0",
            textAlign: "center",
            color: "#DC143C",
            // fontFamily: "birthstone",
            background: "radial-gradient( rgba(255,105,180,0.4) 0%, rgba(255,20,147,0.1) 60%, rgba(0,0,0,0) 90%)",
          }}>
            Experience
          </span>
        </Fade>
      </center>

      <section className="experience-section" style={{ background: "radial-gradient( rgba(255,105,180,0.4) 0%, rgba(255,20,147,0.1) 60%, rgba(0,0,0,0) 90%)" }}>


        <div>
          <VerticalTimeline animated={true} >
            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="January 2023 - April 2023"
              iconStyle={{ boxShadow: "none", backgroundColor: "transparent" }}
              icon={
                <img
                  src={iiithLogo}
                  alt="Raj Reddy Center"
                  // make it larger
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="Raj Reddy Center"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">Raj Reddy Center</h3>
              <h4 className="vertical-timeline-element-subtitle">
                Full Stack Developer Intern
              </h4>
              <p>
                As a team of 4 started developing a web application that automates the student assessment based on the
                student-teacher interactions during class. It starts with basic MCQ’s and True/False, short answer questions and further
                expand the work to long answer questions.
              </p>
            </VerticalTimelineElement>

            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="Jan 2024 - May 2024"
              iconStyle={{ boxShadow: "none", backgroundColor: "transparent" }}
              icon={
                <img
                  src={taLogo}
                  alt="TA Logo"
                  // make it larger
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="TA-logo"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">
                IIITH - Linear Algebra
              </h3>
              <h4 className="vertical-timeline-element-subtitle">
                Teaching Assistant
              </h4>
              <p>
                Worked as a Teaching Assistant for the course Linear Algebra
              </p>
            </VerticalTimelineElement>


            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="May 2024 - July 2024"
              iconStyle={{ boxShadow: "none", backgroundColor: "transparent" }}
              icon={
                <img
                  src={walmartLogo}
                  alt="Walmart"
                  // make it larger
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="Walmart-logo"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">Walmart</h3>
              <h4 className="vertical-timeline-element-subtitle">
                Software Developer Intern
              </h4>
              <p>
                Developed a Performance dashboard application from scratch to analyze the impact of Looper Pro vs. Looper,
                which are CI platforms developed by Walmart with Looper pro being an advanced version of Looper. Also generated job
                reports at various levels.
              </p>
            </VerticalTimelineElement>

            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="Aug 2024 - Dec 2024"
              iconStyle={{ boxShadow: "none", backgroundColor: "transparent" }}
              icon={
                <img
                  src={taLogo}
                  alt="TA Logo"
                  // make it larger
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="TA-logo"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">
                IIITH - Algorithm Analysis and Design
              </h3>
              <h4 className="vertical-timeline-element-subtitle">
                Teaching Assistant
              </h4>
              <p>
                Worked as a Teaching Assistant for the course Algorithm Analysis and Design
              </p>
            </VerticalTimelineElement>

            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="May 2025"
              iconStyle={{ boxShadow: "none" }}
              icon={
                <img
                  src={iiithLogo}
                  alt="IIITH Logo"
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="iiith-logo"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">
                International Institute of Information Technology, Hyderabad,IIITH
              </h3>
              <h4 className="vertical-timeline-element-subtitle">
                Btech in Computer Science and Engineering
              </h4>
              <p>Finished Graduation with a CGPA of 7.87</p>
            </VerticalTimelineElement>

            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="Jan 2025 - May 2025"
              iconStyle={{ boxShadow: "none", backgroundColor: "transparent" }}
              icon={
                <img
                  src={taLogo}
                  alt="TA Logo"
                  // make it larger
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="TA-logo"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">
                IIITH - Linear Algebra
              </h3>
              <h4 className="vertical-timeline-element-subtitle">
                Teaching Assistant
              </h4>
              <p>
                Worked as a Teaching Assistant for the course Linear Algebra
              </p>
            </VerticalTimelineElement>

            <VerticalTimelineElement
              className="vertical-timeline-element--education"
              date="July 2025 - Present"
              iconStyle={{ boxShadow: "none", backgroundColor: "transparent" }}
              icon={
                <img
                  src={walmartLogo}
                  alt="Walmart"
                  // make it larger
                  style={{ width: "100%", height: "100%", borderRadius: "50%" }}
                  className="Walmart-logo"
                />
              }
              shadow={true}
              dateClassName="text-white font-bold text-lg"
            >
              <h3 className="vertical-timeline-element-title">Walmart</h3>
              <h4 className="vertical-timeline-element-subtitle">
                Software Developer Intern
              </h4>
              <p>
                Currently working as a Software Developer Intern at Walmart, focusing on enhancing the performance and scalability of internal tools.
              </p>
            </VerticalTimelineElement>
          </VerticalTimeline>
        </div>
      </section>

      <br></br>
      <br></br>

      <center id="projects">
        <Fade direction="down">
          <span style={{
            fontSize: "2.5em",
            margin: "0 0 40px 0",
            textAlign: "center",
            color: "#DC143C",
            // fontFamily: "birthstone",
            background: "radial-gradient( rgba(255,105,180,0.4) 0%, rgba(255,20,147,0.1) 60%, rgba(0,0,0,0) 90%)",
          }}>
            Projects
          </span>
        </Fade>
      </center>

      <section className="projects-section" >
        <div style={{ height: '600px', position: 'relative' }}>

          <CircularGallery bend={3} textColor="#ffffff" borderRadius={0.05} />

        </div>
      </section>
    </div >
  );
}

export default App;