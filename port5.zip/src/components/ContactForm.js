import React, { useState } from 'react';
import { FaLinkedin, FaInstagram, FaGithub } from "react-icons/fa";
import { SiGmail } from "react-icons/si";
import './ContactForm.css';

import manali from '../images/manali.jpeg';

const ContactForm = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        message: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Form submitted:', formData);
        // Implement backend logic or EmailJS integration here
    };

    return (
        <div className="pink-contact-container">
            <div className="contact-content">
                <div className="contact-left">
                    <h1 style={{ color: "#FF004F" }}>Get in Touch</h1>
                    <p>
                        I’m always open to new ideas, opportunities, or a friendly chat.
                        Drop a message — I’d love to hear from you!

                    </p>

                    <div
                        style={{
                            marginTop: "30px",
                            display: "flex",
                            alignItems: "left",
                            gap: "15px",
                        }}
                    >
                        <a
                            href="https://www.linkedin.com/in/thota-geethika/"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <FaLinkedin size={30} color="#0077b5" />
                        </a>
                        <a
                            href="mailto:thotageethika12@gmail.com"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <SiGmail size={30} color="#D44638" />
                        </a>
                        <a
                            href="https://www.instagram.com/geethu_613/"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <FaInstagram size={30} color="#E4405F" />
                        </a>
                        <a
                            href="https://github.com/iamgeethika"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            <FaGithub size={30} color="#000000" />
                        </a>
                    </div>

                    <br></br>

                    <form className="contact-form" onSubmit={handleSubmit}>
                        <input
                            type="text"
                            name="name"
                            placeholder="Name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                        <input
                            type="email"
                            name="email"
                            placeholder="E-Mail"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                        <textarea
                            name="message"
                            placeholder="Text"
                            rows={4}
                            value={formData.message}
                            onChange={handleChange}
                            required
                        ></textarea>
                        <button type="submit" className="btn">
                            <div style={{textAlign: "center"}}>
                                <center>Submit</center>
                            </div>
                        </button>
                    </form>
                </div>

                <div className="contact-right">
                    <img
                        src={manali}
                        alt="Contact Illustration"
                    />
                </div>
            </div>
        </div>
    );
};

export default ContactForm;
